//Load HTTP library to make call to MS/Server API
var request = require("request-promise-native");

var HOTEL_MS_URL = "http://localhost:4001/api/v1/hotel/info";

function readHotelInfo() {
	return request(HOTEL_MS_URL).then(JSON.parse); 
}

module.exports = {readHotelInfo}; 