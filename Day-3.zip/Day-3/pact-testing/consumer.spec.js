//Load JS testing libraries of your choice
var chai = require("chai");
var sinon = require("sinon");
var sinonChai = require("sinon-chai");
var mockServer = require("./pact-mock-server");
var consumer = require("./consumer");

var expect = chai.expect;
chai.use(sinonChai);


var fetchHotelInfo = {
	state : 'This represents single hotel info',
	uponReceiving: 'This request should return details about a hotel',	
	withRequest: {
		path: '/api/v1/hotel/info',
		method: 'GET'
	},
	willRespondWith: {
		status: 200,
		body : { "rooms": "400", "name": "Hyatt Regency", "location": "RK Puram, New Delhi"}
	}
};


describe("HotelMS Test Cases",function() {

	var sandbox = sinon.createSandbox();

	before(async function(){
		console.log("INFO ======> Inside before()!!!!");
		this.timeout(8000);
		await mockServer.setup(); //Will start mock server
	});


	afterEach(function(){
		console.log("INFO ======> Inside afterEach()!!!!");
		sandbox.restore();
	});

	after(async function(){
		console.log("INFO ======> Inside after()!!!!");
		this.timeout(8000);
		await mockServer.finalize(); //Will write recorded PACT in a file and will stop mock server
	});
		
	describe("Reading Hotel Info",function() {	
		
		it("should read information of hotel from Server",async function(){
			await mockServer.addInteractions(fetchHotelInfo);			

			var data = await consumer.readHotelInfo();
			expect(data).to.eql({"rooms": "400","name": "Hyatt Regency","location": "RK Puram, New Delhi"});	
		});						
	});
	
});



