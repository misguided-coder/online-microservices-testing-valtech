//Load PACT module and create a mock server
var pact = require("pact");

var mockServer = pact({
	consumer:'MobileClient',
	provider:'HotelService',
	port: 4001,
	log: './log/access.log',
	logLevel: 'ERROR',
	dir:'./pacts',
	spec:2	
});

module.exports = mockServer;